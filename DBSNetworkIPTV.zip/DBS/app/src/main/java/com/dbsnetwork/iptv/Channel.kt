package com.dbsnetwork.iptv

data class Channel(
    val name: String,
    val url: String,
    val logo: String
)

