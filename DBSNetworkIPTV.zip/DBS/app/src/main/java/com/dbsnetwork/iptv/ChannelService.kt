package com.dbsnetwork.iptv

import retrofit2.Response
import retrofit2.http.GET

interface ChannelService {
    @GET("channels")
    suspend fun getChannels(): Response<List<Channel>>

    @GET("channels/featured")
    suspend fun getFeaturedChannels(): Response<List<Channel>>
}