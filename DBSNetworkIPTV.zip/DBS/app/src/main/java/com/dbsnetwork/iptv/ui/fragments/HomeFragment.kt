package com.dbsnetwork.iptv

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class HomeFragment : Fragment() {

    private lateinit var featuredChannelsRecyclerView: RecyclerView
    private lateinit var recentlyWatchedRecyclerView: RecyclerView
    private lateinit var popularMoviesRecyclerView: RecyclerView
    private lateinit var channelAdapter: ChannelAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        // Initialize Featured Channels RecyclerView
        featuredChannelsRecyclerView = view.findViewById(R.id.featuredChannelsRecyclerView)
        featuredChannelsRecyclerView.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)

        // Initialize Recently Watched RecyclerView
        recentlyWatchedRecyclerView = view.findViewById(R.id.recentlyWatchedRecyclerView)
        recentlyWatchedRecyclerView.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)

        // Initialize Popular Movies RecyclerView
        popularMoviesRecyclerView = view.findViewById(R.id.popularMoviesRecyclerView)
        popularMoviesRecyclerView.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)

        // Set up adapters
        setupAdapters()

        // Load content
        loadContent()

        return view
    }

    private fun setupAdapters() {
        channelAdapter = ChannelAdapter { channel ->
            // Handle channel click
            activity?.let {
                val intent = android.content.Intent(it, VideoPlayerActivity::class.java)
                intent.putExtra("channelUrl", channel.url)
                startActivity(intent)
            }
        }

        featuredChannelsRecyclerView.adapter = channelAdapter

        // Similar adapters for other RecyclerViews
        // (You can create specialized adapters for movies and TV shows)
    }

    private fun loadContent() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // TODO: Replace with actual API calls for different content types
                val channelService = RetrofitHelper.getInstance().create(ChannelService::class.java)
                val response = channelService.getFeaturedChannels()

                if (response.isSuccessful) {
                    val channels = response.body() ?: emptyList()
                    withContext(Dispatchers.Main) {
                        channelAdapter.submitList(channels)
                    }
                }

                // Similar calls for recently watched and popular movies

            } catch (e: Exception) {
                // Handle errors
            }
        }
    }
}