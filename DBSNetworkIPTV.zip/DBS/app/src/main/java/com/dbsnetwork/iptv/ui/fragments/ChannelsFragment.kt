package com.dbsnetwork.iptv

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class ChannelsFragment : Fragment() {

    private lateinit var channelRecyclerView: RecyclerView
    private lateinit var channelAdapter: ChannelAdapter
    private lateinit var loadingProgressBar: ProgressBar
    private lateinit var emptyStateTextView: TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_channels, container, false)

        channelRecyclerView = view.findViewById(R.id.channelRecyclerView)
        channelRecyclerView.layoutManager = GridLayoutManager(context, 3)

        loadingProgressBar = view.findViewById(R.id.loadingProgressBar)
        emptyStateTextView = view.findViewById(R.id.emptyStateTextView)

        channelAdapter = ChannelAdapter { channel ->
            // Handle channel click
            activity?.let {
                val intent = android.content.Intent(it, VideoPlayerActivity::class.java)
                intent.putExtra("channelUrl", channel.url)
                startActivity(intent)
            }
        }

        channelRecyclerView.adapter = channelAdapter

        // Load channels
        loadChannels()

        return view
    }

    private fun loadChannels() {
        loadingProgressBar.visibility = View.VISIBLE
        emptyStateTextView.visibility = View.GONE

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val channelService = RetrofitHelper.getInstance().create(ChannelService::class.java)
                val response = channelService.getChannels()

                if (response.isSuccessful) {
                    val channels = response.body() ?: emptyList()
                    withContext(Dispatchers.Main) {
                        loadingProgressBar.visibility = View.GONE
                        if (channels.isEmpty()) {
                            emptyStateTextView.visibility = View.VISIBLE
                        } else {
                            channelAdapter.submitList(channels)
                        }
                    }
                } else {
                    // Handle error
                    withContext(Dispatchers.Main) {
                        loadingProgressBar.visibility = View.GONE
                        emptyStateTextView.visibility = View.VISIBLE
                    }
                }
            } catch (e: Exception) {
                // Handle network errors
                withContext(Dispatchers.Main) {
                    loadingProgressBar.visibility = View.GONE
                    emptyStateTextView.visibility = View.VISIBLE
                }
            }
        }
    }
}