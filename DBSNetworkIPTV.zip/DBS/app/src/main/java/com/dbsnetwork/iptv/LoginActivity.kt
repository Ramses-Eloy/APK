package com.dbsnetwork.iptv

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.ui.semantics.text

import com.dbsnetwork.iptv.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set up the login button click listener
        binding.loginButton.setOnClickListener {
            val username = binding.usernameEditText.text.toString()
            val password = binding.passwordEditText.text.toString()

            // Simulate loading
            binding.loadingProgressBar.visibility = View.VISIBLE
            binding.loginButton.isEnabled = false // Disable button during loading

            // **DO NOT DO THIS IN A PRODUCTION APP!**
            if (username == "demo" && password == "demo1") {
                // Simulate successful login
                binding.loadingProgressBar.visibility = View.GONE
                binding.loginButton.isEnabled = true

                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, ChannelListActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                // Simulate failed login
                binding.loadingProgressBar.visibility = View.GONE
                binding.loginButton.isEnabled = true

                binding.errorMessageTextView.text = "Invalid username or password"
                binding.errorMessageTextView.visibility = View.VISIBLE
            }
        }
    }
}