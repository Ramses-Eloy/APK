package com.dbsnetwork.iptv

data class LoginRequest(
    val username: String,
    val password: String
)